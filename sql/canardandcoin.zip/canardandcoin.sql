-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 15, 2018 at 10:13 PM
-- Server version: 10.1.37-MariaDB-0+deb9u1
-- PHP Version: 7.0.33-0+deb9u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `canardandcoin`
--

-- --------------------------------------------------------

--
-- Table structure for table `cac_categories`
--

CREATE TABLE `cac_categories` (
  `idCategorie` int(11) NOT NULL,
  `nomCategorie` varchar(32) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cac_categories`
--

INSERT INTO `cac_categories` (`idCategorie`, `nomCategorie`) VALUES
(1, 'canard');

-- --------------------------------------------------------

--
-- Table structure for table `cac_commandes`
--

CREATE TABLE `cac_commandes` (
  `idCommande` int(11) NOT NULL,
  `idUtilisateur` int(11) NOT NULL,
  `dateCommande` date NOT NULL,
  `idStatut` int(11) NOT NULL,
  `montantCommande` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cac_commandes`
--

INSERT INTO `cac_commandes` (`idCommande`, `idUtilisateur`, `dateCommande`, `idStatut`, `montantCommande`) VALUES
(128, 16, '2018-12-14', 1, 159);

-- --------------------------------------------------------

--
-- Table structure for table `cac_galerieimage`
--

CREATE TABLE `cac_galerieimage` (
  `idProduit` int(11) NOT NULL,
  `idImage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cac_galerieimage`
--

INSERT INTO `cac_galerieimage` (`idProduit`, `idImage`) VALUES
(4, 6),
(4, 9),
(5, 4),
(6, 5),
(7, 3),
(8, 7),
(9, 8);

-- --------------------------------------------------------

--
-- Table structure for table `cac_images`
--

CREATE TABLE `cac_images` (
  `idImage` int(11) NOT NULL,
  `lienImage` varchar(256) NOT NULL,
  `descriptionImage` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cac_images`
--

INSERT INTO `cac_images` (`idImage`, `lienImage`, `descriptionImage`) VALUES
(3, 'images/images_produits/riri.jpg', 'riri'),
(4, 'images/images_produits/fifi.jpg', 'fifi'),
(5, 'images/images_produits/loulou.jpg', 'loulou'),
(6, 'images/images_produits/donald.png', 'donald'),
(7, 'images/images_produits/misstick.jpg', 'misstick'),
(8, 'images/images_produits/picsou.jpg', 'piscou'),
(9, 'images/images_produits/Trump.jpg', 'C\'est dodo trump');

-- --------------------------------------------------------

--
-- Table structure for table `cac_lignecommande`
--

CREATE TABLE `cac_lignecommande` (
  `idCommande` int(11) NOT NULL,
  `idProduit` int(11) NOT NULL,
  `quantiteProduits` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cac_lignecommande`
--

INSERT INTO `cac_lignecommande` (`idCommande`, `idProduit`, `quantiteProduits`) VALUES
(128, 4, 1),
(128, 6, 3);

-- --------------------------------------------------------

--
-- Table structure for table `cac_produits`
--

CREATE TABLE `cac_produits` (
  `idProduit` int(11) NOT NULL,
  `nomProduit` varchar(32) NOT NULL,
  `idCategorie` int(11) NOT NULL,
  `couleurProduit` varchar(32) NOT NULL,
  `descriptionProduit` text NOT NULL,
  `prixProduit` decimal(10,0) NOT NULL,
  `tailleProduit` int(11) DEFAULT NULL,
  `poidsProduit` int(11) DEFAULT NULL,
  `ageProduit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cac_produits`
--

INSERT INTO `cac_produits` (`idProduit`, `nomProduit`, `idCategorie`, `couleurProduit`, `descriptionProduit`, `prixProduit`, `tailleProduit`, `poidsProduit`, `ageProduit`) VALUES
(4, 'Donald', 1, 'bleu', 'C\'est dodo le canard', '150', 2, 59, 15),
(5, 'fifi', 1, 'vert', 'Fifi pas cher', '5', 1, 852, 9),
(6, 'loulou', 1, 'rouge', 'Loulou leaderPrice', '3', 9, 2, 12),
(7, 'Riri', 1, 'bleu', 'Le vrai riri', '15', 5, 5, 5),
(8, 'misstick', 1, 'noir', 'La magie', '15', 2, 2, 2),
(9, 'Picsou', 1, 'Jaune', 'La thune', '10000', 12, 12, 12);

-- --------------------------------------------------------

--
-- Table structure for table `cac_roles`
--

CREATE TABLE `cac_roles` (
  `idRole` int(11) NOT NULL,
  `nomRole` varchar(16) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cac_roles`
--

INSERT INTO `cac_roles` (`idRole`, `nomRole`) VALUES
(0, 'Administrateurs'),
(1, 'Utilisateurs');

-- --------------------------------------------------------

--
-- Table structure for table `cac_statut`
--

CREATE TABLE `cac_statut` (
  `idStatut` int(11) NOT NULL,
  `nomStatut` varchar(32) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cac_statut`
--

INSERT INTO `cac_statut` (`idStatut`, `nomStatut`) VALUES
(1, 'en attente'),
(2, 'prise en charge'),
(3, 'terminée');

-- --------------------------------------------------------

--
-- Table structure for table `cac_utilisateurs`
--

CREATE TABLE `cac_utilisateurs` (
  `idUtilisateur` int(11) NOT NULL,
  `nomUtilisateur` varchar(32) NOT NULL,
  `prenomUtilisateur` varchar(32) NOT NULL,
  `mailUtilisateur` varchar(64) NOT NULL,
  `ageUtilisateur` int(11) NOT NULL,
  `mdpUtilisateur` varchar(64) NOT NULL,
  `ligne1AddresseUtilisateur` varchar(128) NOT NULL,
  `ligne2AddresseUtilisateur` varchar(128) DEFAULT NULL,
  `ligne3AddresseUtilisateur` varchar(128) DEFAULT NULL,
  `cpUtilisateur` varchar(8) NOT NULL,
  `villeUtilisateur` varchar(64) NOT NULL,
  `idRole` int(11) NOT NULL,
  `nonce` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cac_utilisateurs`
--

INSERT INTO `cac_utilisateurs` (`idUtilisateur`, `nomUtilisateur`, `prenomUtilisateur`, `mailUtilisateur`, `ageUtilisateur`, `mdpUtilisateur`, `ligne1AddresseUtilisateur`, `ligne2AddresseUtilisateur`, `ligne3AddresseUtilisateur`, `cpUtilisateur`, `villeUtilisateur`, `idRole`, `nonce`) VALUES
(7, 'papin', 'tilo', 'tilopapin@gmail.com', 18, 'b0b7c7060d02a602b3d0fa029dc00753db49c126b5922c551d242dcdbb09f439', '21 rue marcel sanguy', '', '', '22110', 'Rostrenen', 0, NULL),
(16, 'Amarine', 'Ophélie', 'ophelie@yopmail.com', 19, 'b0b7c7060d02a602b3d0fa029dc00753db49c126b5922c551d242dcdbb09f439', '', '', '', '34090', 'Montpellier', 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cac_categories`
--
ALTER TABLE `cac_categories`
  ADD PRIMARY KEY (`idCategorie`);

--
-- Indexes for table `cac_commandes`
--
ALTER TABLE `cac_commandes`
  ADD PRIMARY KEY (`idCommande`),
  ADD KEY `cac_fk_utilisateurs_commandes` (`idUtilisateur`),
  ADD KEY `cac_fk_statut_commandes` (`idStatut`);

--
-- Indexes for table `cac_galerieimage`
--
ALTER TABLE `cac_galerieimage`
  ADD PRIMARY KEY (`idProduit`,`idImage`),
  ADD KEY `cac_fk_images_galeries` (`idImage`);

--
-- Indexes for table `cac_images`
--
ALTER TABLE `cac_images`
  ADD PRIMARY KEY (`idImage`);

--
-- Indexes for table `cac_lignecommande`
--
ALTER TABLE `cac_lignecommande`
  ADD PRIMARY KEY (`idCommande`,`idProduit`),
  ADD KEY `cac_fk_produits_lignecommande` (`idProduit`);

--
-- Indexes for table `cac_produits`
--
ALTER TABLE `cac_produits`
  ADD PRIMARY KEY (`idProduit`),
  ADD KEY `cac_fk_categories_produits` (`idCategorie`);

--
-- Indexes for table `cac_roles`
--
ALTER TABLE `cac_roles`
  ADD PRIMARY KEY (`idRole`);

--
-- Indexes for table `cac_statut`
--
ALTER TABLE `cac_statut`
  ADD PRIMARY KEY (`idStatut`);

--
-- Indexes for table `cac_utilisateurs`
--
ALTER TABLE `cac_utilisateurs`
  ADD PRIMARY KEY (`idUtilisateur`),
  ADD KEY `cac_fk_roles_utilisateurs` (`idRole`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cac_categories`
--
ALTER TABLE `cac_categories`
  MODIFY `idCategorie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cac_commandes`
--
ALTER TABLE `cac_commandes`
  MODIFY `idCommande` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `cac_images`
--
ALTER TABLE `cac_images`
  MODIFY `idImage` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cac_produits`
--
ALTER TABLE `cac_produits`
  MODIFY `idProduit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `cac_roles`
--
ALTER TABLE `cac_roles`
  MODIFY `idRole` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cac_statut`
--
ALTER TABLE `cac_statut`
  MODIFY `idStatut` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cac_utilisateurs`
--
ALTER TABLE `cac_utilisateurs`
  MODIFY `idUtilisateur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cac_commandes`
--
ALTER TABLE `cac_commandes`
  ADD CONSTRAINT `cac_fk_statut_commandes` FOREIGN KEY (`idStatut`) REFERENCES `cac_statut` (`idStatut`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cac_fk_utilisateurs_commandes` FOREIGN KEY (`idUtilisateur`) REFERENCES `cac_utilisateurs` (`idUtilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cac_galerieimage`
--
ALTER TABLE `cac_galerieimage`
  ADD CONSTRAINT `cac_fk_images_galeries` FOREIGN KEY (`idImage`) REFERENCES `cac_images` (`idImage`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cac_fk_produits_galeries` FOREIGN KEY (`idProduit`) REFERENCES `cac_produits` (`idProduit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cac_lignecommande`
--
ALTER TABLE `cac_lignecommande`
  ADD CONSTRAINT `cac_fk_commande_lignecommande` FOREIGN KEY (`idCommande`) REFERENCES `cac_commandes` (`idCommande`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cac_fk_produits_lignecommande` FOREIGN KEY (`idProduit`) REFERENCES `cac_produits` (`idProduit`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
